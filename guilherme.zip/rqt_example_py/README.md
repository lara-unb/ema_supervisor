rqt_mypkg
=========

A example rqt plugin following http://wiki.ros.org/rqt/Tutorials/Create%20your%20new%20rqt%20plugin#Install_.26_Run_your_plugin and providing additional missing parts
