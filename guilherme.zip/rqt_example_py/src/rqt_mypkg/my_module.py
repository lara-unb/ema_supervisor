import os
import rospkg
import rospy


from python_qt_binding.QtCore import Qt, QTimer, Slot
from python_qt_binding.QtGui import QKeySequence
from python_qt_binding.QtWidgets import QShortcut, QWidget
from qt_gui.plugin import Plugin
from python_qt_binding import loadUi


class MyPlugin(Plugin):
    slider_factor = 1.0
    def __init__(self, context):
        super(MyPlugin, self).__init__(context)
        # Give QObjects reasonable names
        self.setObjectName('MyPlugin')
        rp = rospkg.RosPack()

        # Process standalone plugin command-line arguments
        from argparse import ArgumentParser
        parser = ArgumentParser()
        # Add argument(s) to the parser.
        parser.add_argument("-q", "--quiet", action="store_true",
                      dest="quiet",
                      help="Put plugin in silent mode")
        args, unknowns = parser.parse_known_args(context.argv())
        #if not args.quiet:
        #    print 'arguments: ', args
        #    print 'unknowns: ', unknowns

        # Create QWidget
        self._widget = QWidget()
        # Get path to UI file which is a sibling of this file
        # in this example the .ui and .py file are in the same folder
        ui_file = os.path.join(rp.get_path('rqt_mypkg'), 'resource', 'MyPlugin.ui')
        # Extend the widget with all attributes and children from UI file
        loadUi(ui_file, self._widget)
        # Give QObjects reasonable names
        self._widget.setObjectName('MyPluginUi')
        # Show _widget.windowTitle on left-top of each plugin (when 
        # it's set in _widget). This is useful when you open multiple 
        # plugins at once. Also if you open multiple instances of your 
        # plugin at once, these lines add number to make it easy to 
        # tell from pane to pane.
        if context.serial_number() > 1:
            self._widget.setWindowTitle(self._widget.windowTitle() + (' (%d)' % context.serial_number()))
        # Add widget to the user interface
        context.add_widget(self._widget)
        self._widget.start_angle_value.setText('%0.2f' % ( rospy.get_param('/ema_trike/control/theta/left/min')))
        self._widget.start_angle_slider.setValue(rospy.get_param('/ema_trike/control/theta/left/min'))
        self._widget.end_angle_value.setText('%0.2f' % ( rospy.get_param('/ema_trike/control/theta/left/max')))
        self._widget.end_angle_slider.setValue(rospy.get_param('/ema_trike/control/theta/left/max'))
	self._widget.start_angle_slider.valueChanged.connect(self._on_x_linear_slider_changed)
        self._widget.end_angle_slider.valueChanged.connect(self._on_y_linear_slider_changed)

        self._widget.enviarangulos.pressed.connect(self._enviarangulos_pressed)
    def _on_x_linear_slider_changed(self):
        self._widget.start_angle_value.setText(
        '%0.2f' % (self._widget.start_angle_slider.value()/ MyPlugin.slider_factor))

    def _on_y_linear_slider_changed(self):
        self._widget.end_angle_value.setText(
        '%0.2f' % (self._widget.end_angle_slider.value()/ MyPlugin.slider_factor))

    def _enviarangulos_pressed(self):
        rospy.set_param('/ema_trike/control/theta/left/min', (self._widget.start_angle_slider.value()/ MyPlugin.slider_factor))
        rospy.set_param('/ema_trike/control/theta/left/max', (self._widget.end_angle_slider.value()/ MyPlugin.slider_factor))
