# ema_common_msgs
Repository to hold ROS msgs for EMA project
