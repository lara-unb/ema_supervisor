#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ema.utils import test_imu
from ema.utils import test_stimulator

#test_imu.run()
test_stimulator.run()
