# ema-trike
Repositório do projeto EMA Trike, para a competição Cybathlon 2016
